--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: daftar_transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daftar_transaksi (
    no_order integer NOT NULL,
    tanggal date NOT NULL,
    pembeli character varying(50) NOT NULL,
    item character varying(50) NOT NULL,
    harga_satuan integer NOT NULL,
    kuantitas integer NOT NULL
);


ALTER TABLE public.daftar_transaksi OWNER TO postgres;

--
-- Name: daftar_transaksi_no_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.daftar_transaksi_no_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.daftar_transaksi_no_order_seq OWNER TO postgres;

--
-- Name: daftar_transaksi_no_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.daftar_transaksi_no_order_seq OWNED BY public.daftar_transaksi.no_order;


--
-- Name: gudang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gudang (
    card_id integer NOT NULL,
    nama_kartu character varying(50) NOT NULL,
    tipe_kartu character varying(50) NOT NULL,
    rarity character varying(50) NOT NULL,
    set_kartu character varying(50) NOT NULL,
    stok integer,
    harga_satuan integer
);


ALTER TABLE public.gudang OWNER TO postgres;

--
-- Name: user_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_list (
    username character varying(50) NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    saldo integer
);


ALTER TABLE public.user_list OWNER TO postgres;

--
-- Name: daftar_transaksi no_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daftar_transaksi ALTER COLUMN no_order SET DEFAULT nextval('public.daftar_transaksi_no_order_seq'::regclass);


--
-- Data for Name: daftar_transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daftar_transaksi (no_order, tanggal, pembeli, item, harga_satuan, kuantitas) FROM stdin;
1	2021-06-13	admin@gmail.com	Eevee	5000	1
\.


--
-- Data for Name: gudang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gudang (card_id, nama_kartu, tipe_kartu, rarity, set_kartu, stok, harga_satuan) FROM stdin;
1	Charizard	Fire	Rare	Base set	22	1500
2	Pikachu	Electric	Common	Guardians Rising	12	2500
3	Magikarp	Water	Common	Burning Shadows	387	500
5	Rayquaza GX	Dragon	Ultra Rare	Celestial Storm	7	9500
6	Shiny Charizard VMAX	Fire	Secret Rare	Shining Fates: Shiny Vault	2	750000
7	Lapras V	Water	Ultra Rare	Sword & Shield	11	15000
8	Milotic	Water	Holo Rare	Darkness Ablaze	14	10000
9	Tyranitar	Darkness	Holo Rare	Darkness Ablaze	20	9500
10	Venusaur V	Grass	Ultra Rare	Champions Path	9	6500
11	Jynx	Psychic	Uncommon	Hidden Fates	100	1000
12	Lucario V	Fighting	Ultra Rare	Champions Path	5	15000
4	Eevee	Normal	Holo Rare	Wizard Black Star	22	5000
\.


--
-- Data for Name: user_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_list (username, email, password, saldo) FROM stdin;
kenricovalens	kenrico@gmail.com	kenrico99	30000
ardhisputra	ardhi@gmail.com	ardhi99	50000
zidanramadhan	zidan@gmail.com	zidan99	40000
timothychristian	timothy@gmail.com	timothy99	50000
theodoruslucas	theodorus@gmail.com	theodorus99	50000
admin	admin@gmail.com	admin99	100000
\.


--
-- Name: daftar_transaksi_no_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.daftar_transaksi_no_order_seq', 1, true);


--
-- Name: daftar_transaksi daftar_transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daftar_transaksi
    ADD CONSTRAINT daftar_transaksi_pkey PRIMARY KEY (no_order);


--
-- Name: gudang gudang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gudang
    ADD CONSTRAINT gudang_pkey PRIMARY KEY (card_id);


--
-- Name: user_list user_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_list
    ADD CONSTRAINT user_list_pkey PRIMARY KEY (username);


--
-- PostgreSQL database dump complete
--

