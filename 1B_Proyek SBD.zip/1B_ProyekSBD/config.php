<?php
    $host = "localhost";
    $port = "5432";
    $dbname = "proyeksbd";
    $user = "postgres";
    $password = "postgres"; 
    $connection_string = "host={$host} port={$port} dbname={$dbname} user={$user} password={$password} ";
    $dbconn = pg_connect($connection_string);
    $pg_options = "--client_encoding=UTF8";
?>