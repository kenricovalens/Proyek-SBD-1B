<?php
  require 'config.php';

  if(isset($_POST['submit'])&&!empty($_POST['submit'])){
      $sql ="select * from user_list where email = '".pg_escape_string($_POST['email'])."' and password ='".$_POST['pwd']."'";
      $data = pg_query($dbconn,$sql); 
      $login_check = pg_num_rows($data);
      $email = $_POST['email'];
      if($login_check > 0){ 
          session_start();
          $_SESSION['email'] = $email;
          echo "<meta http-equiv=Refresh content=0;url=http://localhost:3000/storePage.php>";
      }else{
          echo "Invalid details, retrying in 3 seconds...";
          echo "<meta http-equiv=Refresh content=0;url=http://localhost:3000/userLogin.php>";
      }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pokemon TCG Store Login Page</title>
  <meta name="keywords" content="PHP,PostgreSQL,Insert,Login">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<style>
body {
	height: 100vh;
	width: 100%;
	background:url('media/overlay.png'),url('media/WP.jpg');
	background-position: top;
	background-size:cover;
	background-repeat: repeat;
}
</style>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

<a class="navbar-brand" href="#">
    <img src="media/logo.png" width="40" height="40" alt="">
</a>

<a class="navbar-brand" href="index.php">Pokemon TCG Store</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarSupportedContent">
  <ul class="navbar-nav mr-auto">
    <li class="nav-item">
      <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="about.php">About</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="adminLogin.php">Login as Admin</a>
    </li>
  </ul>
</div>
</nav>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="container p-3 mb-2 bg-light text-dark">
  <h2> Login as User</h2>
  <form method="post">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
    </div>
     
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
    </div>
     
    <input type="submit" name="submit" class="btn btn-primary" value="Submit">
  </form>
  <p></p>
</div>
</body>
</html>