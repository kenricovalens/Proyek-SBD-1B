$( document ).ready(function() {

var page = 1;
var current_page = 1;
var total_page = 0;
var is_ajax_fire = 0;

manageData();

/* manage data list */

function manageData() {
    $.ajax({
        dataType: 'json',
        url: url+'api/getData.php',
        data: {page:page}
    }).done(function(data){
    	total_page = Math.ceil(data.total/10);
    	current_page = page;
    	$('#pagination').twbsPagination({
	        totalPages: total_page,
	        visiblePages: current_page,
	        onPageClick: function (event, pageL) {
	        	page = pageL;
                if(is_ajax_fire != 0){
	        	  getPageData();
                }
	        }
	    });

    	manageRow(data.data);
        is_ajax_fire = 1;
    });
}


/* Get Page Data*/

function getPageData() {
	$.ajax({
    	dataType: 'json',
    	url: url+'api/getData.php',
    	data: {page:page}
	}).done(function(data){
		manageRow(data.data);
	});
}

/* Add new Item table row */

function manageRow(data) {
	var	rows = '';
	$.each( JSON.parse(data), function(key, value ) {
	  	rows = rows + '<tr>';
        rows = rows + '<td><img src="media/'+value.nama_kartu+'.jpg" width="100" height="150"></td>';
	  	rows = rows + '<td>'+value.nama_kartu+'</td>';
        rows = rows + '<td>'+value.tipe_kartu+'</td>';
        rows = rows + '<td>'+value.rarity+'</td>';
        rows = rows + '<td>'+value.set_kartu+'</td>';
        rows = rows + '<td>'+value.stok+'</td>';
        rows = rows + '<td>'+value.harga_satuan+'</td>';
        rows = rows + '<td data-card_id="'+value.card_id+'">';
        rows = rows + '<button data-toggle="modal" data-target="#edit-item" class="btn btn-primary edit-item">Edit</button> ';
        rows = rows + '<button class="btn btn-danger remove-item">Delete</button>';
        rows = rows + '</td>';
	  	rows = rows + '</tr>';
	});

	$("tbody").html(rows);
}


/* Create new Item */

$(".crud-submit").click(function(e){
    e.preventDefault();
    var form_action = $("#create-item").find("form").attr("action");
    var card_id = $("#create-item").find("input[name='card_id']").val();
    var nama_kartu = $("#create-item").find("input[name='nama_kartu']").val();
    var tipe_kartu = $("#create-item").find("input[name='tipe_kartu']").val();
    var rarity = $("#create-item").find("input[name='rarity']").val();
    var set_kartu = $("#create-item").find("input[name='set_kartu']").val();
    var stok = $("#create-item").find("input[name='stok']").val();
    var harga_satuan = $("#create-item").find("input[name='harga_satuan']").val();
    
    if(card_id != '' && nama_kartu != ''){
        $.ajax({
            dataType: 'json',
            type:'POST',
            url: url + form_action,
            data:{card_id:card_id, nama_kartu:nama_kartu, tipe_kartu:tipe_kartu, rarity:rarity, set_kartu:set_kartu, stok:stok, harga_satuan:harga_satuan}
        }).done(function(data){ 
            $("#create-item").find("input[name='card_id']").val('');
            $("#create-item").find("input[name='name_kartu']").val('');
            $("#create-item").find("input[name='tipe_kartu']").val('');
            $("#create-item").find("input[name='rarity']").val('');
            $("#create-item").find("input[name='set_kartu']").val('');
            $("#create-item").find("input[name='stok']").val('');
            $("#create-item").find("input[name='harga_satuan']").val('');


            getPageData();
            toastr.success('Item Created Successfully.', 'Success Alert', {timeOut: 5000});
        });
    }else{
        alert('You are missing title or description.')
    }
});

/* Remove Item */

$("body").on("click",".remove-item",function(){
    var card_id = $(this).parent("td").data('card_id');
    var c_obj = $(this).parents("tr");

    $.ajax({
        dataType: 'json',
        type:'POST',
        url: url + 'api/delete.php',
        data:{card_id:card_id}
    }).done(function(data){
        c_obj.remove();
        toastr.success('Item Deleted Successfully.', 'Success Alert', {timeOut: 5000});
        getPageData();
    });
});

/* Edit Item */

$("body").on("click",".edit-item",function(){
    var card_id = $(this).parent("td").data('card_id');
    var nama_kartu = $(this).parent("td").prev("td").prev("td").prev("td").prev("td").prev("td").prev("td").text();
    var tipe_kartu = $(this).parent("td").prev("td").prev("td").prev("td").prev("td").prev("td").text();
    var rarity     = $(this).parent("td").prev("td").prev("td").prev("td").prev("td").text();
    var set_kartu  = $(this).parent("td").prev("td").prev("td").prev("td").text();
    var stok       = $(this).parent("td").prev("td").prev("td").text();
    var harga_satuan = $(this).parent("td").prev("td").text();
    $("#edit-item").find("input[name='nama_kartu']").val(nama_kartu);
    $("#edit-item").find("input[name='tipe_kartu']").val(tipe_kartu);
    $("#edit-item").find("input[name='rarity']").val(rarity);
    $("#edit-item").find("input[name='set_kartu']").val(set_kartu);
    $("#edit-item").find("input[name='stok']").val(stok);
    $("#edit-item").find("input[name='harga_satuan']").val(harga_satuan);
    $("#edit-item").find(".edit-card_id").val(card_id);
});

/* Updated new Item */

$(".crud-submit-edit").click(function(e){ // NEED EDIT
    e.preventDefault();
    var form_action = $("#edit-item").find("form").attr("action");
    var nama_kartu = $("#edit-item").find("input[name='nama_kartu']").val();
    var tipe_kartu = $("#edit-item").find("input[name='tipe_kartu']").val();
    var rarity = $("#edit-item").find("input[name='rarity']").val();
    var set_kartu = $("#edit-item").find("input[name='set_kartu']").val();
    var stok = $("#edit-item").find("input[name='stok']").val();
    var harga_satuan = $("#edit-item").find("input[name='harga_satuan']").val();
    var card_id = $("#edit-item").find(".edit-card_id").val();
   
        $.ajax({
            dataType: 'json',
            type:'POST',
            url: url + form_action,
            data:{card_id:card_id, nama_kartu:nama_kartu, tipe_kartu:tipe_kartu, rarity:rarity, set_kartu:set_kartu, stok:stok, harga_satuan:harga_satuan}
        }).done(function(data){
            getPageData();
            toastr.success('Item Updated Successfully.', 'Success Alert', {timeOut: 5000});
        });
    
});
});
