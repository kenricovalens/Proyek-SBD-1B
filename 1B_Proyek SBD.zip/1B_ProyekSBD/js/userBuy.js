$( document ).ready(function() {

    var page = 1;
    var current_page = 1;
    var total_page = 0;
    var is_ajax_fire = 0;
    
manageData();
    /* manage data list */
    
    function manageData() {
        $.ajax({
            dataType: 'json',
            url: url+'api/getData.php',
            data: {page:page}
        }).done(function(data){
            total_page = Math.ceil(data.total/10);
            current_page = page;
            $('#pagination').twbsPagination({
                totalPages: total_page,
                visiblePages: current_page,
                onPageClick: function (event, pageL) {
                    page = pageL;
                    if(is_ajax_fire != 0){
                      getPageData();
                    }
                }
            });
    
            manageRow(data.data);
            is_ajax_fire = 1;
        });
    }
    
    
    /* Get Page Data*/
    
    function getPageData() {
        $.ajax({
            dataType: 'json',
            url: url+'api/getData.php',
            data: {page:page}
        }).done(function(data){
            manageRow(data.data);
        });
    }
    
    /* Add new Item table row */
    
    function manageRow(data) {
        var	rows = '';
        $.each( JSON.parse(data), function(key, value ) {
            rows = rows + '<tr>';
            rows = rows + '<td><img src="media/'+value.nama_kartu+'.jpg" width="100" height="150"></td>';
            rows = rows + '<td>'+value.nama_kartu+'</td>';
            rows = rows + '<td>'+value.tipe_kartu+'</td>';
            rows = rows + '<td>'+value.rarity+'</td>';
            rows = rows + '<td>'+value.set_kartu+'</td>';
            rows = rows + '<td>'+value.stok+'</td>';
            rows = rows + '<td>'+value.harga_satuan+'</td>';
            rows = rows + '<td data-card_id="'+value.card_id+'">';
            rows = rows + '<button data-toggle="modal" data-target="#buy-item" class="btn btn-primary buy-item">Beli</button>'; // BUY ITEM
            rows = rows + '</td>';
            rows = rows + '</tr>';
        });
    
        $("tbody").html(rows);
    }
    

    /* Buy Item */

    $("body").on("click",".buy-item",function(){
        var card_id = $(this).parent("td").data('card_id');
        var stok    = $(this).parent("td").prev("td").prev("td").data('stok');
        var c_obj = $(this).parents("tr");
        $.ajax({
            dataType: 'json',
            type:'POST',
            url: url + 'api/buy.php',
            data:{card_id:card_id}
        }).done(function(data){
            c_obj.remove();
            toastr.success('Item Bought.', 'Success Alert', {timeOut: 5000});
            getPageData();
        });
    
    });

    });
    