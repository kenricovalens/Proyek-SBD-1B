<?php

    require '../config.php';
    $sql = "DELETE FROM gudang WHERE card_id = '".$_POST['card_id']."'";
    $result = pg_query($dbconn, $sql);

    echo json_encode($_POST['card_id']);
?>