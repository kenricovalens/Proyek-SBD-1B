<?php
    session_start();
    require '../config.php';
    $sql = "UPDATE gudang SET stok = stok - 1 WHERE card_id = '".$_POST['card_id']."'";
    $result = pg_query($dbconn, $sql);

    $sql = "INSERT INTO daftar_transaksi (tanggal, pembeli, item, harga_satuan, kuantitas) VALUES (CURRENT_DATE, '".$_SESSION['email']."', (SELECT nama_kartu FROM gudang WHERE card_id = ".$_POST['card_id']."), (SELECT harga_satuan FROM gudang WHERE card_id = '".$_POST['card_id']."'), 1 )";
    $result = pg_query($dbconn, $sql);

    echo json_encode($_POST['card_id']);
?>