<?php
require '../config.php';

  $result = pg_query($dbconn, "INSERT INTO gudang VALUES ('".$_POST['card_id']."','".$_POST['nama_kartu']."', '".$_POST['tipe_kartu']."', '".$_POST['rarity']."', '".$_POST['set_kartu']."', '".$_POST['stok']."', '".$_POST['harga_satuan']."')");


  $result = pg_query($dbconn, "SELECT * FROM gudang ORDER BY card_id asc LIMIT 1");

  $data = pg_fetch_assoc($result);

  pg_close($dbconn);

echo json_encode($data);
?>