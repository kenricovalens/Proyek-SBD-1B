<?php // = PEOPLE BUY

require '../config.php';
session_start();

$id  = $_POST["card_id"];


  $sql = "UPDATE gudang SET nama_kartu = '".$_POST['nama_kartu']."' , tipe_kartu = '".$_POST['tipe_kartu']."'  , rarity = '".$_POST['rarity']."'  , set_kartu = '".$_POST['set_kartu']."' , stok = '".$_POST['stok']."' , harga_satuan = '".$_POST['harga_satuan']."'  WHERE card_id = '".$id."'";;


  $result = pg_query($dbconn, $sql);


  $sql = "SELECT * FROM gudang WHERE card_id = '".$id."'"; 


  $result = pg_query($dbconn, $sql);

  $sql = "INSERT INTO";
  $result = pg_query($dbconn, $sql);

  $data = pg_fetch_assoc($result);
  pg_close($dbconn);


  echo json_encode($data);


?>