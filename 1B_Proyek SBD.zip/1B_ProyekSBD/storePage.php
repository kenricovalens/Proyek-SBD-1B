<?php
    $host = "localhost";
    $port = "5432";
    $dbname = "proyeksbd1b";
    $user = "postgres";
    $password = "postgres"; 
    $connection_string = "host={$host} port={$port} dbname={$dbname} user={$user} password={$password} ";
    $dbconn = pg_connect($connection_string);
    $pg_options = "--client_encoding=UTF8";

    session_start(); 
    if (!isset($_SESSION['email'])){
        header("Location: userLogin.php");
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Page</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.11.5/validator.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <script type="text/javascript">
    	 var url = "http://localhost:3000/";
    </script>

    <script src="js/userBuy.js"></script>
	
</head>
<style>
body {
	height: 100vh;
	width: 100%;
	background:url('media/overlay.png'),url('media/WP.jpg');
	background-position: top;
	background-size:cover;
	background-repeat: repeat;
}
</style>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

<a class="navbar-brand" href="#">
    <img src="media/logo.png" width="40" height="40" alt="">
</a>

<a class="navbar-brand" href="index.php">Pokemon TCG Store</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarSupportedContent">
  <ul class="navbar-nav mr-auto">
    <li class="nav-item active">
      <a class="nav-link" href="adminPage.php">Home<span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="about.php">About</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="adminPage.php">Admin Page</a>
    </li>
      <li class="nav-item">
        <a class="nav-link active"><?php echo $_SESSION['email']?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="userLogout.php">Log out</a>
      </li>
  </ul>
</div>
</nav>


<div class="container">
<div class="row">
		    <div class="col-lg-12 margin-tb">					
		        <div class="pull-left">
		            <h2 style="color:white">Card Database Management</h2>
		        </div>
		        <div class="pull-right">
		        </div>
		    </div>
		</div>    


		<table class="table table-striped table-light table-bordered">
			<thead>
			    <tr>
					<th>Gambar</th>
					<th>Nama Kartu</th>
					<th>Tipe Kartu</th>
					<th>Rarity</th>
					<th>Set Kartu</th>
					<th>Stok</th>
					<th>Harga</th>
					<th width="200px">Action</th>
			    </tr>
			</thead>
			<tbody>
			</tbody>
		</table>

  

<!-- Small modal 
<button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-sm">alert!</button>

<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      Stok barang ini sudah habis.
    </div>
  </div>
</div>
-->
<footer">
        <center>&copy; Grup 1B, 2021<br />
            <a href="https://www.pokemon.com/us/">Terms of Service</a>
        </center>
    </footer>

</body>
</html>